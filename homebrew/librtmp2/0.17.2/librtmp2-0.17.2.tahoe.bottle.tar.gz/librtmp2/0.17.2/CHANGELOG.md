# Changelog

All notable changes to this project will be documented in this file.

> ⚠️ **Alpha software.** `librtmp2` is in active early development. It has **no
> fixed, stable release version yet** — everything below is pre-release (alpha)
> and the API/ABI may change at any time without notice. Pin to a specific git
> commit if you depend on it.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
While in alpha the project stays on `0.x`; semantic-versioning guarantees only
begin at `1.0.0`.

## [Unreleased]

## [0.17.2] — 2026-11-21

### Fixed
- A fmt=3 chunk that starts a new message uses the extended timestamp value
  when present. ffmpeg carries the actual delta there for deltas >=
  `0xFFFFFF`; the reader previously advanced by the previous delta and jumped
  the timeline. Registry re-initialization now discards the previous session's
  per-CSID state, and a fragmented extended-timestamp message keeps its
  timestamp across continuation chunks.
- Reserved legacy video codec nibbles are no longer cached as keyframes.
  Codecs 8 (RealH263) and 9 (MPEG-4 Part 2) remain cacheable because ffmpeg
  emits them in the wild.
- The generic aggregate decoder rejects zero-length video/data sub-tags,
  matching the session path; zero-length audio is still the RTMP silence
  message.
- The client always advertises the E-RTMP multitrack capability and claims
  reconnect only when a reconnect callback is installed. The capsEx mask used
  to be sent only for reconnect support and omitted the multitrack bit, so a
  v2 server dropped every multitrack frame for this client. A force-released
  publish route now clears the publish role and restarts the setup timer, so
  a displaced publisher that keeps sending is reaped instead of pinning its
  connection slots.
- Every sub-track of an admitted multitrack message reaches the frame
  callback. The poll budget was re-checked per sub-track and silently skipped
  the tail once it was used up; `MAX_MULTITRACK_SUBTRACKS` still bounds the
  work. A same-route republish after media gets a fresh media window;
  cycling without media keeps the prior deadline.
- A FourCC list or video FourCC info map whose public `count` exceeds the
  entry arrays is clamped in the AMF and binary writers and in the
  negotiation reader, instead of panicking on an out-of-bounds index.

### Changed
- Debian packaging uses the non-native quilt source format, loads the
  vendored source archive from `debian/` and uses the standard `1` revision.
  PPA builds default to Ubuntu 26.04 LTS and 26.10, and release tags from
  before the quilt switch can still be republished.
- The play interop CI test runs the librtmp2 client against MediaMTX v1.21.4
  (was v1.21.3).
- Build dependency update: cc 1.11.3.

## [0.17.1] — 2026-11-12

### Fixed
- Enhanced AAC sequence headers are validated like legacy ones before they
  replace the cached AudioSpecificConfig. A malformed enhanced `mp4a` record
  can no longer evict a valid header and be replayed to late joiners; the
  regression test covers both framings.
- Legacy FLV VideoInfo/Command frames (frame type 5) are recognised as
  commands instead of being cached as AVC keyframes. `0x57 0x01` is no
  longer dropped under congestion, and the per-frame callback reports no
  codec identity for it. An enhanced Metadata packet that uses frame type 5
  keeps its FourCC and codec identity.
- The spec-defined zero-length audio silence message is accepted. A server
  with an `on_media_cb` (librtmp2-server always installs one) treated it as
  an unknown codec and closed the publisher. It is reported as `silence`
  without pinning the detected codec, stays critical under congestion, and
  counts toward publisher liveness. Aggregate parsers accept an empty audio
  sub-tag, while empty video and data tags stay invalid.
- An unpeeled ModEx chain is no longer classified as a VideoCommand and can
  no longer bypass the multitrack relay gate; opaque wrappers are handled
  conservatively at fan-out. Legacy G.711U audio (`0x87`) also stays out of
  the ModEx gate.
- A server driven through `poll_ready`/`process_connections_ready` no longer
  skips receive while OpenSSL has decrypted bytes waiting, so an RTMPS
  handshake or command cannot stall until the kernel socket becomes readable
  again.

### Changed
- CI workflows pin third-party GitHub Actions to commit SHAs.

## [0.17.0] — 2026-11-06

### Added
- C publish/play authorization. `lrtmp2_server_set_publish_auth_cb` and
  `lrtmp2_server_set_play_auth_cb` install a synchronous callback with an
  opaque userdata pointer; a zero return allows, any other value denies. The
  C callback takes priority over the Rust hooks on that connection and fails
  closed when a name contains NUL. Without a callback the default stays
  allow, so existing C embedders are source- and behavior-compatible. The
  generated header and the README document the API.

### Fixed
- Replacing or clearing a server's C authorization callback now updates
  already accepted connections. Before, they kept invoking the old callback
  with potentially freed userdata and a newly installed policy was ignored.
- A direct `read_messages` batch clears the buffered-work flag, so a host
  that loops on `has_buffered_messages()` no longer carries the state of the
  previous batch.
- `createStream` re-arms the setup window only when it replaces a live
  publish or play role that carried media. Cycling `createStream` no longer
  extends the setup timeout, so an idle client cannot dodge the reaper and
  squat connection slots.
- A multitrack message is charged once against the per-receive message
  budget instead of once per sub-track. A wide container no longer fails the
  connection or drops the following aggregate sub-tags, every sub-track in
  the message is still authorized, and a separate per-receive track budget
  bounds the work after the current frame. The track budget resets on the
  next receive batch and for direct `read_messages` callers.
- A client session reset clears the deferred terminal I/O error.
- Benchmark tooling rejects unknown, repeated or conflicting arguments
  instead of treating them as the URL.

### Changed
- The C authorization setters document that callbacks must not re-enter the
  same server and setters must not run concurrently with `poll`.
- Build dependency update: cc 1.11.1.

## [0.16.1] — 2026-11-01

### Fixed
- A publisher that keeps sending media is no longer closed for not answering
  RTMP pings. Some hardware encoders (seen with a DJI Osmo Pocket 3) never
  send a ping response, so the server dropped them after about 15 seconds.
  The close reason for a real ping timeout now says so, instead of reporting
  a failed send.
- A peer that keeps sending but stops reading what the server sends is
  closed once no byte of its queued output has reached the socket for
  10 seconds.
- The client delivers media it already received when the peer closes or
  resets the connection, instead of dropping it with the error.
- A compressed (fmt 2/3) chunk header after a zero-length message is
  accepted.
- `releaseStream` also releases a publish route pinned to a different key
  (librtmp2-server pins the database stream id). A playing connection
  cannot release it.
- Reconnect requests accept the same `tcUrl` and description lengths the
  writer produces; an empty `tcUrl` means reconnect to the current URL.
- A legacy AAC sequence header must carry a valid AudioSpecificConfig
  before it replaces the cached one.
- The AVC packet type is read from video tags shorter than five bytes.
- Enhanced audio frames no longer report the legacy sample rate, channel
  and bit-depth bits, which are part of the packet type there.
- Enhanced RTMP video commands and multichannel audio configs, including
  inside multitrack containers, are never dropped under congestion.
- Benchmark tooling: an empty benchmark report fails instead of replacing
  the published one, the relay benchmarks check that frames arrived and
  reject invalid arguments, and the ABI baseline script restores the
  checkout when the baseline build fails.

### Changed
- Dependency update: openssl 0.10.82 (openssl-sys 0.9.118).

## [0.16.0] — 2026-11-01

### Added
- The server answers the Adobe digest ("complex") handshake. A C1 that carries
  a valid Flash Player digest now gets a digest S1 and a signed S2, as from
  FMS, nginx-rtmp and SRS; any other C1 still gets the plain handshake.
  Hardware encoders that verify the server's digest (reported for the DJI
  Osmo Pocket 3) hung up right after the handshake. SHA-256/HMAC are
  implemented in-crate, so `--no-default-features` stays dependency-free.
- Connection logging. Every server connection logs one line when it is torn
  down, with its state, lifetime and the close reason (peer hang-up,
  malformed chunk header with fmt/csid, unsupported C0 byte, invalid
  SetChunkSize, setup/auth timeout, congested player, send failure).
  `connect` is logged at INFO (app, tcUrl with the query redacted, flashVer,
  objectEncoding). Handshake flavour, every received command, peer
  SetChunkSize/WindowAckSize, `_error` replies and error `onStatus` are
  logged at DEBUG/WARN. Media paths do not log.

### Changed
- The play interop CI test runs the librtmp2 client against MediaMTX v1.21.3
  (was v1.9.3) and retries transient release downloads.
- The release workflows pass only the secrets each job needs (PPA signing
  key, crates.io token) instead of `secrets: inherit`, and read the release
  tag through an environment variable.
- Build dependency update: cc 1.10.
- The connect `_result` carries server properties (`fmsVer`, `capabilities`,
  `mode`) instead of `null` and echoes the client's `objectEncoding` in the
  info object, matching what FMS, nginx-rtmp, SRS and MediaMTX send.
- A peer SetChunkSize above 65536 is accepted (RTMP allows up to
  0x7FFFFFFF; sizes beyond the 0xFFFFFF max message length behave the same).
  It used to close the connection. Sizes below 128 are still refused. The
  receive buffer gives back the memory of a large chunk once it is read.
- A fmt=1 chunk header on a chunk stream id the peer has not used yet opens
  that stream with message stream id 0 instead of closing the connection.
  fmt=2/3 on an unknown chunk stream id are still rejected.

### Fixed
- The client no longer stalls on a command reply that spans several chunks.
  `recv_message` parsed one chunk and then blocked on the socket even when
  the rest of the message was already buffered, so e.g. a connect `_result`
  larger than the peer's chunk size only completed once more bytes arrived
  (or the command deadline hit).
- An E-RTMP v2 multitrack `ManyTracks` container holding a zero-length
  sub-track — e.g. the spec-legal empty Opus sequence-start payload — is no
  longer rejected as malformed. The whole container used to fail parsing, so
  the frame was refused with a protocol error and the Opus sequence header
  was never cached for late joiners. The per-container sub-track cap
  (`MAX_MULTITRACK_SUBTRACKS`) still bounds the work a container packed with
  empty tracks can cost.
- The server's per-listener accept rotation now visits every bound listener
  once per sweep. The rotation origin is snapshotted before the sweep instead
  of being read from the field that is advanced after every `accept()`, which
  could starve a listener's `accept()` entirely once three or more listeners
  were bound.
- A local pending-relay overflow is no longer reported to the host as a peer
  protocol violation; the accurate internal-error code is propagated instead.
- A publish grant that failed because the local cache-eviction queue was full
  is no longer answered with "Route already publishing"; the conflict and the
  local-limit case now report different reasons.
- `Server::stop()` is a full teardown: established connections are
  disconnected, their publish-route claims and the socket-less inject claims
  are released, the queued relay media is dropped and the cached init frames
  are cleared, so a later `listen()` cannot resurrect the old sessions or
  keep their routes locked.
- One poll tick no longer runs the connection pipeline twice over every
  connection; only the sockets accepted in that tick get their first pass,
  and the relay-send budget is spent once per tick rather than once per pass.
- The relay-source priority (injected media vs. local media first) rotates
  once per poll tick. The second processing pass flipped it back, so the same
  source always went first and injected media could starve local routes
  under a tight send budget.
- The C header declares `ModexType` and the deprecated `ModexType_Timestamp`
  alias, matching the 0.15.0 Rust API.
- The chunk writer rejects the reserved chunk-stream ids 0 and 1 instead of
  emitting a frame that desynchronizes the receiver.
- The client's command wait is bounded by the receive budget and the
  deadline instead of an undocumented message count, so a peer that answers
  with a few extra status messages is no longer reported as unreachable. A
  reply staged by the read that used up the budget is still delivered.
- Enhanced (E-RTMP) audio metadata frames are marked as metadata, matching
  the enhanced-video and multitrack-audio paths.
- An empty or undefined `colorInfo` value now resets the HDR metadata in
  every encoding, not only in the leading-key string form.
- The client handshake stays in the "waiting for the server hello" state
  after sending C0/C1, so a state-driven caller cannot skip the server's
  version byte and desynchronize the handshake.
- Per-chunk-stream reassembly buffers are allocated lazily and their
  allocation is released when a chunk stream goes dormant, so a peer that
  opens many chunk-stream ids no longer pins a buffer for each of them.
- The `ffmpeg_ingest` example rejects a non-positive minimum frame count
  instead of reporting success without receiving any media.
- The relay benchmark no longer reports a negative average join latency.
- The ABI baseline script compares against the requested ref instead of the
  nearest tag, and finds the built library in the configured cargo target
  directory.
- The benchmark report no longer aborts on a zero throughput estimate.

## [0.15.0] — 2026-10-21

### Changed

- **Breaking (Rust API, not part of the `extern "C"` surface):**
  `ertmp::modex::modex_parse()` / `modex_write()` now implement the E-RTMP v2
  ModEx framing (`modExDataSize` UI8/UI16+1, `modExData`, then one
  `modExType:UB[4] | nextPacketType:UB[4]` byte) instead of the fabricated
  `0x80 | type` marker layout with an eight-byte offset. `ModexType::Timestamp`
  is renamed to `ModexType::TimestampOffsetNano` (wire type 0, a UI24 offset in
  `Modex::offset`); a deprecated `ModexType::Timestamp` alias remains.
  `Modex` gains `next_packet_type`, `modex_write()` emits nothing for
  `ModexType::Nop`, and a new `modex_parse_prefix()` returns the consumed
  length. Framing is now shared with the live relay path
  (`media::modex::parse_modex_layer`), so there is a single ModEx parser.
  Struct-literal users of `Modex` need to set `next_packet_type`.
- **Breaking (Rust API, not part of the `extern "C"` surface):**
  `Server::new` is now `unsafe fn`. It dereferences the raw
  `ServerConfig::tls_cert_file` / `tls_key_file` pointers as C strings, so its
  `# Safety` section now requires both to be NUL-terminated (valid UTF-8) or
  null when TLS is enabled. Safe Rust should use the new
  `Server::from_config(config, tls: Option<(&Path, &Path)>)`, which takes TLS
  filesystem paths and never touches the raw pointer fields.
- `ServerConfig` now implements `Default` (plaintext, null TLS pointers), and
  its TLS path fields document the NUL-termination requirement. The C ABI and
  the layout of `lrtmp2_server_config_t` are unchanged; the header comments now
  state the NUL-termination contract.

### Security
- Hardened enhanced-RTMP parsing and classification: video command and ModEx
  wrappers cannot bypass codec deny lists, video command frames are rejected as
  multitrack containers, malformed or empty AVC/HEVC and multitrack
  sequence-header records are rejected before caching, enhanced audio metadata
  is classified as critical, and the spec-legal empty Opus sequence-start
  payload remains cacheable. A changed sequence header drops the stale cached
  keyframe.
- Hardened connection and send accounting: the TCP connect budget is split
  across resolved addresses, transmitted prefixes are drained from the send
  buffer after a failed blocking send, IPv6 literals keep their brackets in
  `tcUrl` and skip IP-literal SNI, and the active-CSID reassembly cap is O(1)
  instead of a per-chunk registry scan.
- The raw `Server` constructor is now explicitly unsafe (see above); safe Rust
  uses `Server::from_config` and never dereferences caller-owned TLS pointers.

### Fixed
- Chunk parsing rejects a `fmt=2` chunk that interrupts an in-flight message
  without consuming bytes, and abandoned relay-route/cache-eviction markers are
  bounded FIFOs that keep the newest route and drain displaced entries.
- Session/auth handling re-arms the publish-media deadline after a same-route
  republish that follows real media, answers a withdrawn cross-role
  authorization request with a terminal `onStatus`, and releases superseded
  roles without leaving the peer waiting.
- The client surfaces a server `_error` reply instead of waiting for the
  connect/publish timeout, and acknowledgement state tracks the Ack bytes
  rather than the whole send buffer, so flow control keeps working under
  backpressure.
- Stream-cache pressure eviction skips co-tracked entries, the freeable-byte
  estimate matches the actual eviction rule, and reassembling transitions use
  the registry setter so the O(1) count cannot drift.
- Public ModEx parsing/writing now shares the live E-RTMP v2 parser, and the
  `exvideo_write` path can round-trip the wrapper headers that `exvideo_parse`
  accepts.
- Audio/video sequence-header validation covers malformed multitrack configs,
  and a VideoCommand frame is kept out of detected codec state.

## [0.14.0] — 2026-10-14

### Added

- `media::codec_config`: structural validators for
  `AVCDecoderConfigurationRecord` / `HEVCDecoderConfigurationRecord`
  (`validate_avc_record`, `validate_hevc_record`, `validate_config_record`,
  `ConfigCodec`). They check that every length field and count stays inside the
  record and that no parameter set is empty; they never decode video and
  allocate nothing.
- A `video_config` fuzz target with a seed corpus, regression tests for cache
  poisoning, codec switches, RTMP control messages, publisher isolation and
  malformed-connection churn, and an extended churn job in the scheduled fuzz
  workflow. See `docs/malformed-input.md`.

### Changed

- **Behaviour change (init-frame cache):** a malformed or empty AVC/HEVC (or
  multitrack) sequence-header configuration is still relayed live, but is no
  longer classified as a cacheable sequence header, so it can no longer replace
  a previously cached valid header for late joiners. Enhanced RTMP command
  frames (FrameType 5) are never cached as headers or keyframes.
  `classify_cache_frame` now returns `LiveOnly` for such payloads. Hosts that
  feed placeholder sequence headers (for example in tests) need valid records.
- A changed sequence header now drops the cached keyframe of the previous
  configuration; a repeated identical header keeps it.
- Multitrack containers are walked without collecting the tracks into a `Vec`.

## [0.13.0] — 2026-10-14

### Changed

- **Breaking (Rust API, not part of the `extern "C"` surface):**
  `AuthorizationResult::Pending` now carries the integrator's `request_id`, and
  `complete_publish_authorization` / `complete_play_authorization` (on both
  `Conn` and `Server`) take it. A completion therefore resolves only the request
  it was issued for: a decision for a request the connection has already
  discarded -- its stream torn down or replaced, or the opposite role granted in
  the meantime -- is ignored instead of being applied to whichever request holds
  the slot by then. The id must be unique per connection and role; a request
  reusing an id the connection already answered is denied, because its
  completion could not be told apart from the one still owed for the earlier
  request.
- The pending-authorization slot is no longer kept occupied by a tombstone after
  a teardown or after the opposite role is granted. The freed slot is usable by
  the next request immediately, so such an event no longer costs a new publish
  or play request a full pending-auth timeout before it can be decided.
- The publish-side media/route gates consult only a pending *publish* decision,
  and the player-side gates only a pending *play* decision. A play request
  awaiting a decision no longer stops an already-authorized publisher's relay
  (and vice versa); a republish awaiting a decision still stops that publisher's
  media, as before.

### Removed

- The internal `withdrawn` tombstone mechanism on pending authorizations, which
  request ids replace.

## [0.12.0] — 2026-10-10

### Added
- Native Windows support (x86_64 and ARM64, MSVC) for RTMP and RTMPS, client
  and server. All socket calls now go through `src/net/`, with a Unix backend
  (`recv`/`send`/`sendmsg`/`poll`, unchanged) and a Winsock backend
  (`recv`/`send`/`WSASend`/`WSAPoll`), selected at compile time. See
  `docs/windows.md`.
- `net::RawSocket` / `net::INVALID_SOCKET` (the platform socket handle type and
  its "no socket" value) and `Transport::from_tcp_stream()`.
- Cross-platform loopback integration tests (`tests/cross_platform_transport.rs`)
  and native Windows x64/ARM64 CI jobs.

### Changed
- Socket-handle fields and methods (`client_fd`, `server_fd`,
  `listener_fds()`, `Transport::fd()`, `Transport::new_plain()`,
  `TlsCtx::accept()`) use `net::RawSocket`, which is `i32` on Unix (no change)
  and `u64` on Windows.
- `Server::listen_reuseport()` / `listen_tls_reuseport()` return
  `ErrorCode::Unsupported` on Windows, which has no `SO_REUSEPORT`.
- On Unix the transport now puts its socket into `O_NONBLOCK` mode when it
  takes it over (as the Windows backend does with `FIONBIO`). macOS ignores
  `MSG_DONTWAIT` on `send`/`sendmsg`, so a plaintext client could block once
  the socket buffer was full. On Windows a socket that cannot be made
  non-blocking is closed instead of stalling the poll loop.
- `examples/minimal_server` binds `127.0.0.1:1935` by default (pass an
  address as the first argument to expose it), because it accepts every
  publish and play request.
- CI builds, tests and `cargo publish` use the committed `Cargo.lock`
  (`--locked`).
- A release tag is built and tested on macOS and Windows (x86_64 and ARM64)
  before anything is published; previously only Linux gated the release.
- CI benchmark history is kept in `bench/` on `main` (`bench/latest.json`,
  `bench/releases/<tag>.json`) instead of a separate `bench-data` branch;
  `bench/` is excluded from the published crate.

### Fixed
- Async publish/play authorization: a decision that arrives after its stream
  was torn down or replaced (`FCUnpublish`/`deleteStream`, `closeStream`, a
  new `createStream`) is a silent no-op instead of authorizing whatever
  request came next. The withdrawn request keeps its slot until the stale
  completion or the timeout clears it, so `has_pending_authorization()` stays
  `true` until then.
- A pending authorization reaped by the 15 s timeout now also closes the
  connection: the deny response is flushed, then the server tears the
  connection down in the same tick, so the client has to reconnect to try
  again. The reaped slot stays sealed, so a completion that arrives later can
  never authorize a newer request.
- A republish on an already-publishing connection (for example a stream
  rename) no longer keeps relaying media under the old authorization while
  the new decision is pending, and a deferred-relay publisher's media counts
  toward the squat deadline.
- `poll(2)` interrupted by a signal (`EINTR`) during a blocking send or a TLS
  accept is retried instead of failing the connection with `Io`.
- The client's receive loop retries the read after a TLS `WANT_WRITE` once
  the socket is writable, instead of giving up on a writable socket.
- Chunk reader: a fmt=3 chunk that starts a new message right after a fmt=0
  message repeats the fmt=0 timestamp as its delta (RTMP spec 5.3.1.2.4),
  instead of reusing the previous message's timestamp.
- The client handles `AbortMessage` in all of its dispatch paths and discards
  the partial message on the aborted CSID.
- Legacy FLV `SoundFormat` 14 is MP3 8 kHz, not Opus (Opus is only signaled
  through the E-RTMP ExHeader); reserved legacy sound format nibbles are
  rejected, and unregistered enhanced FourCCs are no longer labeled H.264.
- `AMF3_DATA` messages have their one-byte AMF0 marker stripped even when it
  is the whole body, and re-parsing `connect` or the `connect` `_result` into
  a reused `ConnectInfo`/`NegotiatedCaps` no longer keeps stale optional
  fields.
- The init cache ignores unpeeled ModEx wrappers instead of parsing them as
  an ex-header, and a route whose only cached video is the combined
  `avc_header` is classified as multitrack so congested players can resync
  on audio.
- Client: a fatal `recv` error ends `poll()` with `Io` instead of returning
  `Ok` forever (which busy-spun embedders on a reset socket); a failed
  `connect()` resets the previous session so a later `publish()` cannot
  stream to the old server; a full send buffer while publishing is treated as
  "not writable yet" instead of aborting the session; and a receive that ends
  on a partial chunk no longer spins.
- The transport's 10 s send poll timeout is an absolute deadline instead of
  restarting on every iteration.
- `examples/minimal_server` registers its publish/play callbacks so it
  actually accepts streams, `examples/minimal_client` sends the frame type it
  declares, and `bench_handshake`/`bench_relay` reject `--count 0` and stop
  on a dead viewer.
- `scripts/bench_report.py` reads and writes its reports as UTF-8 and retries
  the baseline fetch, keeping the measurements when it fails.
- Broken links in the API documentation (`AuthDecision`, `split_host_port`,
  `Conn`); CI now builds the docs with warnings as errors.

## [0.11.0] — 2026-10-02

### Added
- `DeliveryHint` (`Critical` / `ResyncPoint` / `Droppable`): the codec-neutral
  congestion class the relay already used per player, now public.
  `RelayFrame::delivery_hint()` classifies a frame from the existing init-cache
  classification, and `Server::drain_exported_relay_frames_with_hints()` returns
  each exported frame with its hint so a cluster relay can apply live-media
  backpressure without parsing codecs. `drain_exported_relay_frames()` is
  unchanged.
- `examples/bench_relay` prints an additional machine-readable `delivered:` line
  (aggregate Gbit/s and frames per viewer); existing output is unchanged.

### Changed
- Fan-out sends no longer allocate per player and `sendmsg`: the iovec array
  lives on the stack (`Transport::try_send_vectored` takes the remaining parts
  plus an offset), and `Conn::send_staged_media` no longer builds a window
  `Vec` per call.
- `StagedRelayMedia` groups each player's messages while staging (a linked list
  per connection in one arena) instead of sorting all `frames × players`
  messages by connection after the fan-out; the send order per player is
  unchanged.

### Tests
- Vectored-send tests on a socketpair (full and partial writes, resume at an
  offset, more than `MAX_SEND_PARTS` parts, `EAGAIN`, empty parts, closed
  peer), per-connection ordering of staged relay messages (staged and buffered
  players receive byte-identical streams), and `DeliveryHint` classification
  (H.264, E-RTMP, audio-only, script/metadata, malformed payloads).

### Notes
- Measured with `librtmp2-server`'s load benchmark (500–2000 viewers) the
  fan-out changes show no CPU regression and no gain beyond run-to-run noise:
  the cost is dominated by the kernel TCP path. See `librtmp2-server`'s
  `BENCHMARKS.md`.
- Additive public API only (`DeliveryHint`, `RelayFrame::delivery_hint`,
  `Server::drain_exported_relay_frames_with_hints`); no FFI change.

## [0.10.2] — 2026-09-28

### Changed
- The server relay no longer copies each relayed frame into every
  player's send buffer. A frame is chunked once, and after the fan-out
  every player gets its own headers plus the shared chunk bodies in one
  vectored `sendmsg`; only what the socket does not take is buffered.
  With 1000 viewers on one 2.6 Mbps stream the server's memory drops from
  about 59 MiB to 32 MiB at unchanged CPU. TLS players keep the buffered
  path.
- A newly accepted player receives the cached init frames (metadata,
  sequence headers, last keyframe) in the same write as
  `NetStream.Play.Start`, instead of after every other connection in the
  same poll has been read.

### Added
- `examples/bench_handshake.rs` takes `--play` to measure connect + play
  latency (up to `NetStream.Play.Start`) against a live stream.

## [0.10.1] — 2026-09-27

### Fixed
- The chunk reader's cap on concurrently reassembling chunk stream IDs now
  counts only CSIDs with a message in flight. CSIDs that finished their last
  message no longer count against it, so the cap no longer acts as a
  lifetime limit on a long-lived connection. Restarting a message on such a
  dormant CSID counts like opening a new one, so a peer still cannot open
  more incomplete messages than the cap allows.
- The outbound client now acknowledges the server's `WindowAckSize`: once
  that many bytes have arrived it sends an Acknowledgement with the running
  byte count (wrapping at `u32` as the protocol expects). At most one
  Acknowledgement is queued at a time, and queued control bytes are flushed
  even while the client is only receiving, so servers that stop sending
  until they are acknowledged no longer stall playback.
- An enhanced (E-RTMP) video frame with a FourCC the library doesn't know
  keeps its codec unset instead of being labelled H.264.
- `vp08` and `vvc1` are no longer advertised as supported video FourCCs.
- An enhanced audio tag (ExHeader nibble 9) is recognized as enhanced even
  when its FourCC is not in the registry, instead of being parsed as a
  legacy tag.
- HDR `colorInfo` metadata is accepted in the reference layout written by
  FFmpeg (a leading `"colorInfo"` string before the object) as well as a
  bare object. An undefined or empty `colorInfo` resets the HDR metadata.
- A truncated AAC sequence header (shorter than 2 bytes) is rejected
  instead of being passed on as a codec configuration.
- `SharedObjectMessage::is_persistent` follows the de-facto wire
  convention (flags `2` for persistent, `0` otherwise) instead of reading
  bit 0.

## [0.10.0] — 2026-09-25

### Added
- Per-player outbound flow control on the server relay. A player whose unsent
  backlog exceeds `Server::player_send_buffer_soft_limit` (default 4 MiB)
  skips live audio/video until it has drained to half that and a video
  keyframe arrives (any audio frame on an audio-only route, or for a player
  that doesn't receive the route's video), so slow viewers
  jump ahead cleanly instead of accumulating latency and memory. Codec headers
  and metadata are always delivered. Players are disconnected at
  `player_send_buffer_hard_limit` (default 32 MiB, previously the 64 MiB
  buffer cap) or after `player_congestion_timeout` (default 15 s) without any
  drain progress; a fully drained player waiting for a keyframe is never
  timed out. A new play, unpause or stream teardown clears the state.
  Skipped frames are counted in `Conn::relay_frames_dropped`.
- `Client::publish_chunk_size` (default 4096, like ffmpeg and OBS): the client
  announces it with `SetChunkSize` when publishing starts instead of sending
  all media in 128-byte chunks.
- Compact media chunk headers: server connections and the client use fmt=1/2
  first-chunk headers when the previous message on the same chunk stream
  allows it (`Server::compact_media_headers`, `Client::compact_media_headers`,
  on by default); extended timestamps always use fmt=0.
- `examples/flv_publish.rs` and `tests/interop/publish_interop.sh`: publish
  interop test of the client against MediaMTX and nginx-rtmp.

### Changed
- Package version `0.9.3` → `0.10.0` (new public server/client API
  above; the per-player hard limit default drops from 64 MiB to 32 MiB).
- Relay fan-out chunks each frame's payload once per chunk size and copies it
  to every player behind that player's own first header, instead of
  re-chunking it per player; receiving players are collected in one scan.
- `Buffer::write` only compacts when the tail lacks space instead of moving
  the whole unread backlog on every write; new `Buffer::reserve`.
- `chunk_write` reserves the whole message up front, so a message that does
  not fit leaves no partial bytes behind.

### Fixed
- A player on a slow link is no longer disconnected by the keepalive ping
  timeout while media is still visibly draining to it: its pong was merely
  queued behind the backlog. Idle or stalled peers still time out.

## [0.9.3] — 2026-09-24

### Fixed
- Reject malformed `SetChunkSize` control messages with payloads shorter than
  four bytes or chunk sizes outside the supported RTMP range instead of
  silently ignoring or clamping them; client and server receive paths now
  propagate the protocol error consistently.
- Clamp the configured server outbound chunk size to the supported RTMP range
  before advertising it to peers.

### Changed
- Crate version `0.9.2` → `0.9.3`.

## [0.9.2] — 2026-09-23

### Changed
- Split `Server::process_connections_impl()`, the poll loop's per-tick
  driver, into seven focused phase methods: recv/timeout reaping,
  abandoned-route cleanup, relay-frame batching, init-frame replay, relay
  send/export, connection flush, and closed-connection teardown. Behavior
  is unchanged; this addresses a SonarCloud Cognitive Complexity finding
  (175 against a limit of 30) with no functional difference.

### Documentation
- Documented, for the first time in this file, two pieces of release
  infrastructure that predate this entry and were previously described
  only in `CLAUDE.md`/`docs/`: Debian/Ubuntu packaging (`librtmp2` +
  `librtmp2-dev`, built from `debian/`) published to a Launchpad PPA on
  tag push (`.github/workflows/publish-ppa.yml`, see
  `docs/publishing-ppa.md`), and automated crates.io publishing on tag
  push (`.github/workflows/publish-crates-io.yml`, `release.yml`).

## [0.9.1] — 2026-09-23

### Security
- Require explicit publish/play authorization when a server registers only
  `on_shared_object_cb`. Previously, that observer-only configuration could
  implicitly accept publish/play commands and enable relay without the matching
  publish/play authorization callback. Such commands are now rejected and
  `relay_enabled` remains false unless the corresponding authorization path is
  configured.

### Changed
- Crate version `0.9.0` → `0.9.1`.

## [0.9.0] — 2026-09-23

### Added
- `AuthorizationResult` (`Allow` / `Deny` / `Pending`) as the return type for
  the server's publish/play authorization callbacks, so a host application
  can defer a decision (e.g. an async database or cluster lookup) instead of
  answering synchronously from inside the RTMP poll loop. A connection with a
  pending authorization is held open — no media flows and the state machine
  doesn't advance — until the host resolves it via the new
  `Conn`/`Server::complete_publish_authorization` /
  `complete_play_authorization`. A pending authorization left unresolved for
  15 seconds (`DEFAULT_PENDING_AUTH_TIMEOUT`) is automatically denied.
  Existing synchronous bool-returning callbacks keep working unchanged; the
  two callback styles can't both be registered on the same connection.
- `Conn::has_pending_authorization()` to check whether a connection is
  currently waiting on an async publish/play decision.

## [0.8.1] — 2026-09-18

### Security
- Capped multitrack/aggregate media fan-out against the per-poll message
  budget on both sides: the client no longer lets aggregate/multitrack
  messages dispatch past `MAX_MESSAGES_PER_POLL`, and the server decrements
  the budget per multitrack sub-track; `pending_cache_evictions` is now
  capped and publish renames are rejected once the limit is reached.
- `max_connections_reached()` now counts pending RTMPS handshakes together
  with active connections, closing a bypass where an attacker could fill
  the configured `max_connections` cap with stalled TLS handshakes and then
  open additional plaintext sessions up to roughly double the intended
  limit.
- Play/teardown sessions no longer refresh the setup-timeout window on
  teardown or `createStream` unless media actually flowed (sent, received,
  or injected), closing a way to squat a stream slot indefinitely across
  repeated teardown/`createStream` cycles.
- Multitrack `on_media_cb` authorization now charges the per-recv message
  budget for sub-tracks after the first and rejects over-budget containers
  with `Protocol`, restricted to connections that actually register an
  `on_media_cb` callback (the frame-callback path enforces its own budget
  separately).
- Aggregate message sub-tags — including unknown sub-tag types — now count
  individually against the per-recv message budget, and zero-length
  sub-tags are rejected, closing a CPU-amplification gap left by the
  aggregate budgeting added in `0.8.0`.

### Fixed
- Script/metadata tags are sent as AMF0 data instead of an AMF0 command,
  chunk reassembly keeps draining a message when a fragment is already
  buffered instead of stalling, E-RTMP audio FourCCs are mapped instead of
  dropped, and AMF decoding rewinds correctly after a failed
  connect-capabilities read instead of skipping the type byte twice.

### Changed
- Reduced branching complexity in media-frame handling across
  `session/conn.rs`, the client, and the server module (internal refactor,
  no behavior change).

## [0.8.0] — 2026-09-03

### Added
- `FCPublish` / `releaseStream` command support.
- AMF3 shared object delivery, gated behind a new `on_shared_object_auth_cb`
  so servers must explicitly authorize shared objects at the protocol layer.
- HDR `colorInfo` for enhanced (E-RTMP) video frames, kept off `Frame`'s
  ABI-stable layout (see `docs/abi-policy.md`) and exposed via a separate
  accessor.
- ExVideo/ExAudio write helpers for emitting E-RTMP v1 media.
- E-RTMP v2 reconnect capability support.

### Security
- Publish, play, and shared-object commands are no longer accepted on
  connections that configure only `on_frame_cb` or only `on_media_cb`
  without the matching `on_publish_cb`/`on_play_cb`/`on_shared_object_auth_cb` —
  closing an auth bypass for servers that use those hooks purely for
  frame/codec observation.
- Wildcard E-RTMP media FourCC (`*`, meaningful only in capability
  negotiation) is treated like an unknown codec identity for
  `on_media_cb` authorization instead of bypassing codec-specific deny lists.
- `ModEx` wrapper payloads can no longer bypass `on_media_cb` codec deny
  lists.
- Non-UTF-8 FourCC and unknown legacy codec nibbles are surfaced to
  `on_media_cb` via stable labels instead of `None`, and frames with no
  resolvable codec identity are denied; `tls_insecure` now requires the
  FFI value `1` (not any non-zero) to disable RTMPS certificate
  verification.
- Zero-size E-RTMP multitrack sub-tracks are rejected as malformed,
  closing a CPU-amplification path where a ~16 KiB `ManyTracks` container
  could otherwise trigger millions of per-track callback invocations.
- Aggregate message sub-tags now count individually against per-recv/per-poll
  message budgets instead of the whole aggregate consuming a single slot,
  closing an amplification path of up to ~1M handler invocations per batch.
- IPv4-mapped IPv6 peer addresses are canonicalized before per-IP connection
  and pending-TLS caps are applied, so dual-stack listeners can't bypass
  them; a full global TLS pending-handshake queue now rejects new stalled
  handshakes instead of evicting unrelated queued peers.

### Fixed
- Pause/unpause cycling no longer refreshes the session setup timer for
  players that have never received outbound relay, closing a way to hold
  connection slots indefinitely without consuming media.
- Unpaused play sessions that never receive outbound relay (no publisher,
  no cache replay) are reaped after the setup grace window, like paused
  squatters; players actively receiving relay are unaffected.
- Stale relay activity is no longer retained across pause grace.

### Changed
- Crate version `0.7.0` → `0.8.0`.

## [0.7.0] — 2026-08-09

### Added
- Public integrator APIs for external media export and socket-less inject:
  - `RelayFrame` is part of the crate root / `session` public API (documented fields).
  - `Server::enable_relay_export` / `disable_relay_export` /
    `drain_exported_relay_frames` — bounded drainable export of publisher
    relay frames (disabled by default = zero extra copies; overflow drops
    oldest frames).
  - `Server::inject_relay_frame` — inject media into the local relay /
    init-cache / player fan-out path without a socket (per-route external
    publisher ids; `EXTERNAL_RELAY_PUBLISHER_ID` sentinel; soft-capped by
    `MAX_EXTERNAL_PUBLISH_ROUTES`).
  - `Server::release_injected_route` /
    `Server::release_all_injected_routes` — free socket-less publish claims.
  - `Conn::inject_relay_frame` — queue frames on an existing publisher
    connection (skips `on_media_cb`; integrator-trusted).
  - `Server::stream_init_snapshot` + `StreamInitSnapshot` — copy cached
    metadata / codec headers / last keyframe for late joiners or remote
    subscribers.

### Changed
- Crate version `0.6.0` → `0.7.0`.

### Fixed
- Disconnect teardown no longer exports budget-deferred `pending_relay` frames
  before orphaning them; export happens once on the next-poll fan-out path.
- Orphaned local relay frames skip `cache_relay_frame` when their publisher is
  no longer in `connections`, so teardown cannot recreate dead cache ownership.
- `orphaned_relay` is capped via `push_orphaned_relay` (`MAX_PENDING_RELAY_FRAMES`
  and `max_pending_relay_bytes`), dropping oldest frames until a new one fits;
  dropped local frames are still exported once so HA does not permanently miss them.
- `session_setup_timed_out` with no `current_stream` sustains inject claims that
  already received media and applies `PUBLISH_MEDIA_REQUIRED_TIMEOUT` when they
  have not, instead of always using `RTMP_SESSION_SETUP_TIMEOUT`.
- Socket-less inject allocates external route IDs only after pending-queue and
  publish-route validation succeed, so failed injects cannot leak
  `external_route_ids` entries the stale reaper never sees.
- `Conn::inject_relay_frame` counts script/metadata injects toward
  `injected_media_bytes` so deferred-relay connections drain those frames.
- Stream-cache byte precheck treats same-publisher peer cache keys as freeable,
  matching `evict_for_stream_cache_pressure`.
- Stale inject-route reaper skips routes that still have frames in
  `pending_injected_relay`, indexing pending routes once per poll.
- Deferred-relay connections drop abandoned `pending_relay` frames when
  `relay_enabled` is cleared so later inject/reauth cannot resurrect them.
- `claim_publish_route` enqueues cache eviction when an inject switches routes.
- Deferred-relay no longer discards inject frames queued before `publish`
  resets `injected_media_bytes` for the media deadline.
- Local publisher `pending_relay` queues are round-robin merged (with a rotating
  lead) so the first connection cannot starve later publishers under a tight
  relay-send budget.
- Failed `Conn::inject_relay_frame` after a route switch restores the previous
  publish claim and undoes the pending cache eviction for the abandoned route.
- Stream-cache entry-cap eviction runs only after the byte-budget freeable
  precheck, so a too-small victim is not deleted when the new entry still
  cannot fit.
- Stream-cache per-publisher key-limit eviction likewise runs only after the
  byte-budget freeable precheck.
- Abandoned-route pruning of `pending_relay` applies only under deferred relay
  with `relay_enabled` cleared, so normal publishers keep same-batch media
  through FCUnpublish/deleteStream for fan-out and export.
- Local relay round-robin concatenates same-route publisher queues in encounter
  order before fairness across routes, so an A→B handoff cannot emit B before
  A's already-accepted final frames.
- Failed inject route-switch restores `relay_key` to the still-held claim;
  releasing idle inject claims also queues cache eviction; stale inject routes
  are reaped before publish commands in `process_connections`.
- Inject queue-failure rollback restores `relay_key` together with the previous
  publish claim so socket media cannot queue under the rejected route.
- Relay round-robin groups mixed publisher queues by each frame's route; only
  `onMetaData` Script payloads enter the init cache; cache reservation credits
  headers cleared by combined↔per-track representation switches.
- Closed publishers' deferred relay frames stay in a server orphan queue for
  player fan-out; local↔inject merge keeps same-route handoff order.
- Relay export no longer re-exports frames deferred by the per-poll send budget.
- Relay merge keeps same-route local deferred frames ahead of injects, then
  round-robins independent routes so neither multi-route source starves.
- Oversized export frames clear the export buffer before being skipped, so
  drainers do not keep only stale pre-overflow data.
- Stream-cache ownership is recorded only after a successful storage
  reservation, so failed external injects do not grow `publisher_cache_keys`.
- `set_conn_id_base` / `allocate_conn_id` reject IDs with the high bit set so
  socket conn ids cannot collide with `is_external_publisher_id`.
- Stream-cache byte accounting includes `(app, stream_name)` key string
  storage; inject rejects oversized route component strings.
- External inject cache ownership uses a stable per-route publisher id in the
  high-bit range (`is_external_publisher_id`) instead of one shared id for all
  routes.
- Pending-relay byte limits count `app` / `stream_name` string storage; inject
  rejects payloads above the RTMP 24-bit wire maximum (`RTMP_WIRE_MAX_MSG_LENGTH`).
- Stream-cache pressure can evict other external routes (per-route IDs blocked
  same-owner eviction); empty `publisher_cache_keys` rows are pruned.
- Socket-less inject claims `(app, stream_name)` in `active_publish_routes` so
  inject and local publishers cannot share one route's init cache.
- `Conn::inject_relay_frame` counts audio/video toward publisher liveness
  (`injected_media_bytes`) without changing socket receive telemetry.
- `release_injected_route` / `release_all_injected_routes` free external
  publish claims; claims are not auto-reaped between polls so continuous
  non-cacheable inject feeds stay exclusive until explicit release.
  New unique claims beyond `MAX_EXTERNAL_PUBLISH_ROUTES` (1024) are rejected
  so cycling routes without release cannot grow `active_publish_routes`
  without bound.
- Cache-budget projection subtracts only the replaced field after peer
  eviction; reservations whose own irreducible size (including other fields
  retained on the same route) exceeds `max_stream_cache_bytes` reject without
  wiping peer routes.
- Injected liveness is reset on new/renamed publish and on every
  publish-route eviction path (including idle `!was_publishing` teardown).
- Fair inject↔local interleave alternates which source leads each poll so a
  budget of 1 cannot permanently starve one side.
- Relay export flushes budget-deferred frames when their publisher connection
  is removed in the same poll.
- `Conn` relay/inject payload limits follow `chunk_reg.max_msg_length`, capped
  at `RTMP_WIRE_MAX_MSG_LENGTH` (24-bit RTMP message length).

### Removed
- Accidental `scripts/docker_cargo_test.py` helper (local Windows Docker
  workaround; not part of the library).

## [0.6.0] — 2026-08-06

### Security
- Client `onStatus` handling now requires `level == "status"` and the exact
  expected success `code` (`NetStream.Publish.Start` / `NetStream.Play.Start`)
  before treating `publish()`/`play()` as successful, instead of only
  rejecting `level == "error"`. A malicious server could previously omit
  `level` entirely or return an unrelated success-shaped status to make a
  failed publish/play look successful to the caller.
- Client-side `Frame` codec metadata for ModEx-wrapped E-RTMP v2 payloads is
  now derived from the negotiated `capsEx` and the unwrapped inner codec
  header instead of the raw ModEx wrapper, matching the server's existing
  behavior.
- `ChunkRegistry` CSID lookups are now O(1) via a `HashMap` index instead of
  a linear scan, closing a DoS path where a peer opening many chunk streams
  multiplied per-chunk registry-scan cost.
- `Client::publish()`/`play()` no longer abort on a transitional `status`-level
  `onStatus` code (e.g. `NetStream.Play.Reset`, sent by real-world servers
  before the terminal status) — they keep waiting for the expected terminal
  code instead, sharing one bounded inbound-byte budget across the retry so
  the added tolerance can't be used to process unbounded inbound data for a
  single publish/play exchange.
- The server now reaps a publisher that claims a route but sends no media
  within a short setup deadline, closing a route-squatting window where a
  connection could hold a publish route indefinitely without ever streaming;
  the deadline restarts only for a genuinely new publish session or route,
  not for a repeated `publish` command on the route the connection already
  owns.
- `play` is now rejected on connections authorized only via `on_publish_cb`,
  mirroring the existing guard that already rejected `publish` on
  play-only-configured hosts — closes a play-to-publish authorization bypass.
- `defer_media_relay` is now honored even when publish/play auth callbacks
  are unset, closing a bypass where relay could start before the host's
  deferred-authorization step ran.
- Paused play clients are now reaped after the session setup timeout like
  other idle connections; pausing no longer lets a client sit outside relay
  delivery — and thus outside the slow-reader disconnect path — indefinitely.
  The grace window resets when `pause(true)` is received.
- Init-cache replay is no longer rescheduled on every `receiveAudio`/
  `receiveVideo` toggle; it fires once on first play, and repeated
  play-route changes on the same connection are now rate-limited to one
  cached-header replay per second, closing a DoS path where a client could
  force repeated multi-megabyte replays. Script/metadata live relay and
  init-cache metadata replay are also now skipped entirely for connections
  with both `receiveAudio` and `receiveVideo` disabled, closing a bandwidth
  amplification path.
- `Client::connect()`'s DNS resolution queue now retries admission until the
  connect deadline elapses instead of failing outright once the shared
  32-slot queue is full. The queue itself was reworked from a busy-poll +
  `mpsc` channel (which woke every blocked caller roughly once per
  millisecond) to a `Mutex`/`Condvar`-based bounded queue, so callers block
  until a real state change instead of spinning. Already-expired deadlines
  are now rejected before queue admission instead of after, and a freed slot
  is relayed to the next waiter with a still-valid deadline instead of being
  stranded behind a waiter whose deadline has already elapsed.

### Added
- Automated C header generation: `cbindgen.toml`, `scripts/generate-header.sh`,
  and `.github/workflows/c-header.yml` regenerate, verify (compile under
  `-Wall -Wextra -Werror`), and commit `include/librtmp2/librtmp2.h` on
  `src`/config changes, with the header staged into both source and binary
  release tarballs and Debian packaging (`librtmp2-dev`).

### Changed
- `message::command::read_onstatus` now takes an `expected_code: &str`
  parameter and returns `Result<bool>` (matched vs. non-matching status)
  instead of `Result<()>`. `ChunkRegistry` gained private fields for the CSID
  index and reassembly-byte accounting. Both are internal (non-`extern "C"`)
  API changes, permitted at this `0.x` stage per `docs/abi-policy.md`; the
  `extern "C"` FFI surface is unaffected.
- `lrtmp2_server_listen`'s `bind_addr`, `lrtmp2_client_connect`'s `url`, and
  the `lrtmp2_version_string()`/`lrtmp2_error_string()` return types are now
  `*const std::ffi::c_char` instead of `*const u8` in the exported C API,
  matching what README.md already documented and what the generated header
  now reflects. Behavior is unchanged (these were always NUL-terminated C
  strings internally), but this is a signature change to `extern "C"`
  functions, so downstream C/FFI callers should recompile against the
  regenerated header.
- The generated header now wraps declarations in `extern "C" { ... }`
  (cbindgen `cpp_compat`) so C++ translation units link against the correct
  unmangled symbols, and opaque types are renamed to match the names
  README.md documents (`lrtmp2_server_t`, `lrtmp2_server_config_t`,
  `lrtmp2_client_t`, `lrtmp2_frame_t`, `lrtmp2_conn_t`) instead of raw Rust
  identifiers.

### Fixed
- The release workflow now checks out `inputs.tag` (falling back to the
  triggering ref) in both its build and packaging jobs, instead of always
  building the workflow's triggering ref while labeling artifacts with the
  requested tag — a manual `workflow_dispatch` release with a tag input
  could previously ship the wrong commit.

## [0.5.0] — 2026-07-24

### Security
- The TLS pending-handshake queue's per-address cap is now keyed on the peer
  IP instead of the full `ip:port` peer address, so a single host can no
  longer bypass it by opening incomplete RTMPS handshakes from distinct
  ephemeral source ports.
- `on_media_cb` codec authorization now checks every track's codec inside a
  multitrack (`ManyTracks`/`ManyTracksManyCodecs`) container instead of only
  the first, closing a path where a disallowed codec could ride along
  behind an allowed first track.
- Duplicate `play` commands and rapid `receiveAudio`/`receiveVideo` re-enable
  toggles can no longer repeatedly trigger multi-megabyte cached init-frame
  replay. Replay requests are deduplicated and independently rate-limited per
  media type.
- Stream-cache growth and eviction are scoped to the publishing connection,
  preventing one publisher from evicting another publisher's cached codec
  headers, metadata, or keyframes.
- Connections that finish AMF `connect` but never publish or play are closed
  after the setup deadline. Active connections are also limited per source IP,
  independently from the pending-TLS-handshake cap, and the accept loop has a
  per-poll budget so rejected connection floods cannot starve established
  sessions.
- Per-CSID chunk-read scratch allocations are released after copying and are
  bounded with the existing buffer-retention threshold, preventing stalled
  partial messages from retaining large duplicate buffers outside the normal
  reassembly accounting.

### Added
- `ServerConfig::max_pending_tls_per_addr` — configures the per-peer-IP cap
  on incomplete TLS handshakes (default `4` when `0`/unset). Deployments
  where many clients share one source IP (NAT, load balancer, proxy) can
  raise this to avoid spurious RTMPS handshake evictions under bursty
  connect patterns.
- `ServerConfig::max_connections_per_addr` — independently configures the
  maximum number of active plaintext/RTMPS connections accepted from one
  source IP (default `4` when `0`/unset). This is a new public struct field,
  so downstream Rust struct literals and FFI callers that allocate
  `ServerConfig` by value must be recompiled for `0.5.0`.

### Changed
- `Server::poll()` now processes stale connections before enforcing admission
  caps, accepts only a bounded number of sockets per pass, and immediately
  processes newly accepted sockets in the same poll tick.
- The ABI policy now explicitly distinguishes source compatibility from binary
  re-link compatibility when fields are appended to `#[repr(C)]`
  configuration structs. Existing binaries compiled against an older,
  smaller `ServerConfig` layout must be rebuilt before using this release.

### Fixed
- Client AMF3 data delivery no longer creates an unnecessary intermediate
  payload copy before invoking the frame callback.
- `FCUnpublish`, `deleteStream`, and `closeStream` now consistently clear
  publish/play/paused state and only restart the idle grace window after a
  genuine active-to-idle transition. This prevents both premature disconnects
  of reusable connections and timeout bypasses from repeated teardown commands.
- Reconnects are no longer spuriously rejected by the per-IP cap when an old
  socket is already stale and due to be removed in the same poll cycle.
- Newly accepted connections receive their first processing pass immediately
  instead of waiting for the next poll interval.

## [0.4.2] — 2026-07-21

### Security
- `Client::publish()` and `Client::play()` now bound their blocking AMF
  exchange with the configured connect-timeout wall-clock deadline instead
  of passing `None`, closing a stall window where a malicious server could
  hold the caller for up to ~650 seconds (64 recv polls × 10s) after connect
  succeeded.
- AMF route strings (connect `app`, publish/play stream names) are now
  decoded with strict UTF-8 validation and the command is rejected on
  failure; invalid UTF-8 previously collapsed to an empty string via
  `unwrap_or`, letting distinct wire-level names collide onto the same
  `(app, stream)` relay route.
- `read_string_checked()` now rejects embedded NUL bytes instead of copying
  them verbatim and letting `decode_route_amf_string()`'s NUL-sentinel scan
  truncate the value later, which let distinct invalid route values collapse
  onto the same app/stream route — undermining the UTF-8 collision guard
  above.
- The server session layer now rejects empty connect `app` names and empty
  publish/play stream names, and gates `onMetaData`/script relay to players
  and the stream cache on `on_media_cb` being registered.

### Fixed
- `bytes_received` is now tracked as `u64` (was `u32`), so WindowAckSize
  pacing stays correct once a connection passes 4 GiB of inbound data
  instead of wrapping.
- The client's Aggregate-message play path now passes sub-tag slices
  directly to `on_frame_cb` instead of cloning each sub-tag into a new
  `Vec`.

## [0.4.1] — 2026-07-18

### Changed
- `Client::connect()` now enforces a single wall-clock deadline across DNS
  resolution, TCP/TLS connect, the RTMP handshake, and the AMF
  `connect`/`createStream` exchange (previously only DNS/TCP connect were
  bounded). The default budget is unchanged (`TCP_CONNECT_TIMEOUT_SECS`, 10s);
  callers on slower or more loaded hosts can raise it with the new
  `Client::set_connect_timeout()`.

### Fixed
- Capped chained ModEx extension unwrapping at 32 layers to prevent CPU
  amplification from deeply nested wrappers on media frames.
- `Conn` now tracks the exact `PublishRouteRegistry` key it claimed and
  releases that same key on `FCUnpublish`/`closeStream`/play takeover,
  instead of re-deriving a route key from the current `relay_key` at release
  time. Fixes stale route ownership (blocking other publishers) and stale
  `stream_cache` entries when a host integrator pins `relay_key` after the
  initial publish claim.
- `publish()` now clears `Stream.is_playing` (mirroring what `play()` already
  does for `is_publishing`), so a play→publish switch on the same connection
  is correctly observable by hosts polling stream role flags.

## [0.4.0] — 2026-07-15

### Added
- Server-side E-RTMP v2 connect negotiation on the live session path:
  `fourCcList`, numeric `capsEx` capability bitmask, `videoFourCcInfoMap`,
  `reconnect`, and NetConnection `_error` responses when capability negotiation
  fails.
- Multitrack media support (E-RTMP v2 `AudioPacketType::Multitrack` /
  `VideoPacketType::Multitrack`): opaque relay of full multitrack messages,
  per-track `on_frame_cb` delivery with `Frame.track_id`, and init-cache replay
  of multitrack sequence-start headers to late-joining players.
- Enhanced init-frame classification via `exvideo`/`exaudio` parsers (HEVC, AV1,
  Opus, AAC) in `media/init_cache.rs`, replacing legacy nibble-only detection.
- `onMetaData` script caching in `StreamCache` and replay to players that join
  after the publisher has already sent metadata.
- Client receive path for AMF0/AMF3 `onMetaData` and RTMP Aggregate messages
  (`0x16`), unpacking sub-tags into the normal A/V and script frame callbacks.
- Legacy RTMP commands on the server session path: `pause`, `seek`,
  `receiveAudio`, `receiveVideo`, and `closeStream`.
- User Control message handling for `StreamBegin`, `StreamEOF`, and
  `SetBufferLength`; AMF3 Shared Object messages are accepted as no-ops.
- `examples/dump_frames.rs` — play a stream and print one line per received frame
  (type, timestamp, size, codec details) for debugging live publishers.
- libFuzzer harnesses under `fuzz/` for chunk reading, handshake parsing, AMF0
  skipping, E-RTMP parsers, and RTMP control-message decoders.
- CI jobs: `.github/workflows/sanitizers.yml` (ASan unit tests, overflow-check
  unit tests, ASan example builds) and `.github/workflows/fuzz.yml` (scheduled
  libFuzzer smoke runs).

### Changed
- The built-in relay fan-out budget is configurable through
  `Server::max_relay_sends_per_poll` (default: 4096 sends per poll). The first
  eligible frame in a poll is always processed even when its audience exceeds
  the budget, preventing an oversized fan-out frame from being re-queued forever.
- Connect AMF helpers now parse and write E-RTMP v2 capability representations,
  including wildcard FourCC entries, numeric `capsEx`, and per-codec
  `videoFourCcInfoMap` masks. The built-in client continues to connect without
  advertising capabilities; negotiation is active on the server session path.
- `Frame` now carries populated codec/header fields (`video_fourcc`, `audio_fourcc`,
  composition time, etc.) and optional `track_id` for multitrack callbacks.
- Corrected E-RTMP audio/video packet-type constants for sequence-end,
  multichannel, and multitrack values.
- Removed `docs/roadmap.md`; release status lives in `README.md` and
  `CHANGELOG.md`.

### Fixed
- ModEx prefix bytes are normalized only when the ModEx capability was negotiated
  and the leading bytes form an unambiguous ModEx wrapper; enhanced
  ExVideo/ExAudio, legacy AAC, and multitrack tags are preserved. Relay always
  forwards the original payload.
- Aggregate processing preserves relative sub-tag timestamps for A/V and metadata,
  rejects malformed or truncated payloads, and routes script tags through the
  normal metadata path.
- Re-enabling `receiveAudio` or `receiveVideo` schedules init-cache replay;
  paused players and disabled media types are filtered during relay.
- Enhanced `CodedFramesX` keyframes and multitrack sequence headers are classified
  correctly for late-join cache replay.
- Complex RTMP handshake (digest/HMAC) is not implemented; peers requesting it
  still receive a legacy simple S1/S2 response so ffmpeg and similar clients connect.

### Security
- Bound E-RTMP capability blobs to 4 KiB and Aggregate messages to 4096 sub-tags
  on both server and client receive paths; stream-cache resource accounting now
  includes metadata and per-track headers.

## [0.3.1] — 2026-07-13

### Fixed
- `Client::connect()` DNS resolution now respects the TCP connect deadline
  instead of blocking indefinitely in the system resolver; lookups run on a
  single shared worker thread with a bounded job queue, and worker startup
  failures return `ErrorCode::Internal` instead of panicking.
- `send_frame_payload()` and `lrtmp2_client_send_frame` now service inbound
  RTMP UserControl ping requests before sending media, so in-tree clients
  stay connected when the server enforces ping timeouts.
- Ping responses issued while draining inbound messages during `poll()` or
  publishing now use nonblocking `try_send` instead of blocking
  `Transport::send()`, so a zero-timeout poll cannot stall for up to 10
  seconds on a peer that stops reading.
- `service_inbound_nonblocking()` now honors the same per-poll byte and
  message budgets as `poll()`, and stops reading on transient EAGAIN instead
  of spinning until the socket blocks.
- Server-side ping RTT tracking starts only after the ping has fully left
  `send_buffer`; unflushed pings queued behind a slow reader no longer start
  the timeout early, and pings stuck unflushed longer than `PING_TIMEOUT`
  now close the connection. RTT timing now tracks the ping's own queued byte
  range instead of waiting for the entire `send_buffer` to drain, so prompt
  ping responses are not discarded when later media remains queued.
- `Client::poll()` now works while publishing to service inbound pings and
  retry queued ping responses after transient `EAGAIN`, and the shared DNS
  worker is re-created after a transient thread-spawn failure instead of
  permanently caching the error in a `OnceLock`.
- Publishing clients now poll for socket writability (`POLLOUT`) when queued
  pong bytes remain after a transient `EAGAIN`, so idle publishers can flush
  keepalive responses without sitting out the full read timeout.
- Publishing clients also poll `POLLOUT` when the send queue backs up during
  media upload, and preserve the correct TLS poll direction when flushing
  queued pong bytes after a transient `EAGAIN`.
- Nonblocking publish sends now propagate `try_flush_send_buffer()` errors
  instead of dropping flush failures on the floor.

### Security
- Inbound peers that open TCP but never complete the AMF connect exchange
  (including partial legacy handshake bytes) are now closed after a 10-second
  setup deadline instead of holding a connection slot until
  `max_connections` is reached.
- Server connections with unanswered or stale outbound RTMP pings are now
  closed instead of accumulating indefinitely in `pending_pings`.
- DNS lookups abandoned after the connect deadline no longer spawn unbounded
  detached resolver threads, and the shared resolver job queue is capped so
  wedged lookups cannot grow heap usage without bound.

## [0.3.0] — 2026-07-12

### Fixed
- `lrtmp2_client_create()` silently ignored `ServerConfig.tls_ca_file` and
  `ServerConfig.tls_insecure` — the client always verified `rtmps://` peers
  against only the system trust store regardless of what those fields were
  set to, even though the ABI documented them as controlling client TLS
  verification. `Client`/`Transport::connect_tls` now honor a caller-supplied
  CA bundle or an explicit opt-out of verification.
- `Transport::connect_tls()`'s `ca_file` option now *replaces* the trust
  store instead of adding the caller's CA bundle to the system default trust
  store — a custom CA is meant to restrict which peers are trusted, not
  merely extend the existing set.
- `insecure = true` no longer loads the system's default CA verify paths at
  all, so `rtmps://` connections with verification intentionally disabled no
  longer fail on hosts without a usable default CA store.
- `lrtmp2_client_create()` now rejects (returns NULL for) a non-UTF-8
  `tls_ca_file` path instead of silently discarding it and falling back to
  default verification.

### Changed
- `Transport::connect_tls()` (Rust-only API, not part of the FFI ABI) gained
  two new parameters (`ca_file: Option<&str>`, `insecure: bool`) to support
  the fix above. Bumped the minor version per this crate's pre-1.0
  versioning policy (breaking Rust API change, ABI/FFI surface unaffected).

## [0.2.1] — 2026-07-10

### Added
- `lrtmp2_tls_supported()` runtime capability check exported to FFI
- Parse `onMetaData` from RTMP data messages into `Conn` fields (duration, width, height, framerate, videodatarate, audiodatarate, codec info)

### Fixed
- `flv::audio_tag` / `video_tag` / `script_tag` parsers now reset the
  caller-owned tag struct at the start of every `parse()` call, so switching
  between codecs mid-stream (or a shorter value following a longer one, e.g.
  a script tag name) no longer leaves stale fields from a previous parse
- CodeQL invalid-pointer alert in FFI `server_create` test resolved
- Borrow checker errors in AMF0 `skip_value_depth`
- `onMetaData` parsing scope and lifecycle per review feedback

### Security
- Cap and copy FFI frame payloads before sending and reject an oversized
  `frame.size`; ignore inbound media whose `msg_stream_id` doesn't match
  the current stream; retain `on_frame_cb` payloads in connection-scoped
  scratch buffers instead of a shared one
- Add per-poll (256 KiB) and per-command-wait (256 KiB) byte budgets to the
  RTMP client's recv path, mirroring the server's existing fairness cap, so
  a malicious server can no longer monopolize the embedder's event-loop
  thread or force hundreds of megabytes through the AMF connect handshake
- `lrtmp2_server_create` now substitutes a default `max_connections` (256)
  when the FFI caller passes a zero-initialized `ServerConfig` (e.g. via
  `calloc`/`{0}`), which previously disabled all connection limiting; an
  explicit negative value continues to mean "unlimited", matching
  `Server::new`

### Documentation
- Improved `onMetaData` parsing robustness per CodeRabbit/Codex reviews

## [0.2.0] — 2026-07-10

### Added
- RTMP Aggregate message (`0x16`) handling: aggregate-framed audio/video
  from a publisher is now unpacked and relayed through the normal
  media-frame path instead of being silently dropped

### Fixed
- `Client::connect()` now actually accepts `rtmps://` URLs via the new
  `Transport::connect_tls()` (dialing over TLS and verifying the server
  certificate against the system trust store) — previously only the
  server side implemented RTMPS, despite the 0.1.0 notes describing
  client-side `rtmps://` support; `parse_rtmp_url()` now recognizes the
  scheme and defaults to port 443
- `flv::audio_tag` / `video_tag` / `script_tag` parsers now reset the
  caller-owned tag struct at the start of every `parse()` call, so switching
  between codecs mid-stream (or a shorter value following a longer one, e.g.
  a script tag name) no longer leaves stale fields from a previous parse
- The RTMP client's inbound recv budget accounting no longer discards an
  already-read chunk once it slightly exceeds the remaining budget; the read
  itself is now capped at the remaining budget so bytes belonging to the
  response being waited for are never dropped
- `Client::poll()` no longer risks blocking in `poll(2)` for the full
  timeout when TLS already has decrypted plaintext buffered internally from
  a previous budget-limited drain
- FFI `lrtmp2_client_send_frame` and `Client::send_frame_payload` now
  enforce the max client frame-size cap consistently on every call path,
  and reject a stale/non-owned frame pointer when the client isn't in the
  `Publishing` state, instead of only checking on one of two paths
- The server poll loop keeps draining a connection's already-buffered
  messages (up to 3 extra passes) when a batch exceeds the per-recv message
  budget, instead of stalling until the peer happens to send more bytes
- The RTMPS client now checks TLS support before dialing, instead of
  opening a plaintext TCP connection first even in a
  `--no-default-features` build that given an `rtmps://` URL would only
  reject after connecting
- The client's blocking read helpers now poll for write-readiness (not
  just read-readiness) when a TLS read reports `WANT_WRITE` during
  renegotiation, instead of stalling until timeout on the wrong direction
- The client's TLS handshake is now bounded by the same 10s timeout used
  elsewhere in the transport, instead of blocking indefinitely if a peer
  stalls mid-handshake
- Retry `poll(2)` on `EINTR` in the client's transport-readiness wait
  helper instead of surfacing it as a hard I/O error and aborting the
  caller's read/handshake

### Security
- Cap and copy FFI frame payloads before sending and reject an oversized
  `frame.size`; ignore inbound media whose `msg_stream_id` doesn't match
  the current stream; retain `on_frame_cb` payloads in connection-scoped
  scratch buffers instead of a shared one
- Add per-poll (256 KiB) and per-command-wait (256 KiB) byte budgets to the
  RTMP client's recv path, mirroring the server's existing fairness cap, so
  a malicious server can no longer monopolize the embedder's event-loop
  thread or force hundreds of megabytes through the AMF connect handshake
- `lrtmp2_server_create` now substitutes a default `max_connections` (256)
  when the FFI caller passes a zero-initialized `ServerConfig` (e.g. via
  `calloc`/`{0}`), which previously disabled all connection limiting; an
  explicit negative value continues to mean "unlimited", matching
  `Server::new`

## [0.1.1] — 2026-07-08

### Fixed
- Cap per-connection recv drain in `process_connections()` to 256 KiB per
  poll pass, preventing a peer that keeps its kernel recv buffer full from
  starving other sessions in the single-threaded poll loop

### Documentation
- Update docs.rs badge to track the latest published version

## [0.1.0] — 2026-07-08

First tagged pre-release. `librtmp2` is a Rust crate (built via Cargo as
`cdylib`/`staticlib`/`lib`) exposing both an idiomatic Rust API and an
FFI-compatible `extern "C"` layer for consumption from C, Go, Python, PHP,
and others.

### Added
- TLS / RTMPS support via OpenSSL, enabled by default through the `tls`
  Cargo feature (`cargo build --no-default-features` for a zero-dependency,
  plaintext-only build)
- Transport abstraction shared by plaintext RTMP and TLS so the layers above
  never branch on the wire type
- Server-side TLS termination and client-side `rtmps://` connect with SNI
  and certificate verification
- `lrtmp2_tls_supported()` runtime capability check
- Legacy RTMP protocol support (handshake, chunk, message, AMF0)
- Enhanced RTMP v1 support (ExVideo/ExAudio headers, FourCC registry, HDR/colorInfo)
- Enhanced RTMP v2 support (capsEx, reconnect, multitrack, ModEx)
- Full server API with callbacks (`on_connect`, `on_publish`, `on_play`, `on_frame`, `on_close`)
- Full client API with publish/play flows
- Frame API supporting audio, video, script, and metadata types
- H.264, H.265, AV1, and legacy video codec support
- AAC, Opus, MP3, G.711 audio codec support
- Example programs: `minimal_server`, `minimal_client`, `play_pull`, `ffmpeg_ingest`
- Inline unit tests throughout `src/`, an end-to-end loopback integration
  test (`tests/server_client_loopback.rs`), and interop shell scripts
  (`tests/interop/`)
- ABI baseline tooling (`scripts/abi-baseline.sh`) for `0.x` compatibility checks
- Automated ABI compliance checks in CI (`cargo-semver-checks` via `.github/workflows/abi-check.yml`)

### Security
- Bounds-checked parsers for all network-provided length fields
- Constant-time RNG for handshake
- Safe handling of unknown E-RTMP v2 ModEx types (degrades to NOP, not panic)

### Documentation
- `CLAUDE.md` with build commands and architecture guide
- `docs/abi-policy.md` with ABI compliance checklist
- Protocol mapping documents for legacy, E-RTMP v1, and E-RTMP v2
- `CONTRIBUTING.md` guidelines

[Unreleased]: https://github.com/OpenRTMP/librtmp2/compare/v0.17.2...HEAD
[0.17.2]: https://github.com/OpenRTMP/librtmp2/compare/v0.17.1...v0.17.2
[0.17.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.17.0...v0.17.1
[0.17.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.16.1...v0.17.0
[0.16.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.16.0...v0.16.1
[0.16.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.15.0...v0.16.0
[0.15.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.14.0...v0.15.0
[0.14.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.13.0...v0.14.0
[0.13.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.12.0...v0.13.0
[0.12.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.11.0...v0.12.0
[0.11.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.10.2...v0.11.0
[0.10.2]: https://github.com/OpenRTMP/librtmp2/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.10.0...v0.10.1
[0.10.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.9.3...v0.10.0
[0.9.3]: https://github.com/OpenRTMP/librtmp2/compare/v0.9.2...v0.9.3
[0.9.2]: https://github.com/OpenRTMP/librtmp2/compare/v0.9.1...v0.9.2
[0.9.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.9.0...v0.9.1
[0.9.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.8.1...v0.9.0
[0.8.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.5.0...v0.6.0
[0.5.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.4.2...v0.5.0
[0.4.2]: https://github.com/OpenRTMP/librtmp2/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.3.1...v0.4.0
[0.3.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.2.1...v0.3.0
[0.2.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/OpenRTMP/librtmp2/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/OpenRTMP/librtmp2/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/OpenRTMP/librtmp2/releases/tag/v0.1.0
